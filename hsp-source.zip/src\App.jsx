import { BrowserRouter, Routes, Route } from 'react-router-dom';
import HomePage from './pages/HomePage';
import TestPage from './pages/TestPage';
import ResultPage from './pages/ResultPage';
import ReportPage from './pages/ReportPage';
import ArticlesPage from './pages/ArticlesPage';
import BlogPostPage from './pages/BlogPostPage';
// English pages
import EnHomePage from './pages/en/HomePage';
import EnTestPage from './pages/en/TestPage';
import EnResultPage from './pages/en/ResultPage';
import EnReportPage from './pages/en/ReportPage';
import EnArticlesPage from './pages/en/ArticlesPage';
import EnBlogPostPage from './pages/en/BlogPostPage';

export default function App() {
  return (
    <BrowserRouter>
      <Routes>
        {/* Chinese */}
        <Route path="/" element={<HomePage />} />
        <Route path="/test" element={<TestPage />} />
        <Route path="/result" element={<ResultPage />} />
        <Route path="/report" element={<ReportPage />} />
        <Route path="/articles" element={<ArticlesPage />} />
        <Route path="/blog/:slug" element={<BlogPostPage />} />
        {/* English */}
        <Route path="/en" element={<EnHomePage />} />
        <Route path="/en/test" element={<EnTestPage />} />
        <Route path="/en/result" element={<EnResultPage />} />
        <Route path="/en/report" element={<EnReportPage />} />
        <Route path="/en/articles" element={<EnArticlesPage />} />
        <Route path="/en/blog/:slug" element={<EnBlogPostPage />} />
      </Routes>
    </BrowserRouter>
  );
}
